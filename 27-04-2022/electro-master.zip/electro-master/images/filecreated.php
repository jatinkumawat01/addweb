<?php
$path = "Ac/";
mkdir($path, 0777);
?>