<?php

$pdo = new PDO("mysql:host=localhost;dbname=batch6", "root", "");

?>